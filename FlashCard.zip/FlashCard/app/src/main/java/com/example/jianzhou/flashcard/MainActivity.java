package com.example.jianzhou.flashcard;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {


    TextView firstNum, secNum, operater;
    Button btnSub;
    RadioButton add, sub;
    EditText answer;

    Random random = new Random();

    public int num1, num2, correctAns;

    public int count;
    public int score;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        firstNum = (TextView)findViewById(R.id.firstNum);
        secNum = (TextView)findViewById(R.id.secNum);
        operater = (TextView)findViewById(R.id.sign);

        add = (RadioButton)findViewById(R.id.plus);
        sub = (RadioButton)findViewById(R.id.minus);

        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                operater.setText("-");
                questionMaker();
                answer.setText("");
            }
        });


        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                operater.setText("+");
                questionMaker();
                answer.setText("");
            }
        });

        questionMaker();

        answer = (EditText)findViewById(R.id.res);
        btnSub = (Button)findViewById(R.id.submit);

        btnSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count++;
                if(judge()){
                    score++;
                }

                if(count>=10){
                    Toast.makeText(getApplicationContext() ,"Your score:" + score +" out of 10 questions!",Toast.LENGTH_SHORT).show();
                    restart();
                }

                questionMaker();
                answer.setText("");
            }
        });




    }

    public void questionMaker(){
        num1 = random.nextInt(10);
        num2 = random.nextInt(10);

        firstNum.setText("" + Math.max(num1,num2));
        secNum.setText("" + Math.min(num1,num2));

        if(sub.isChecked()){
            correctAns = Math.max(num1,num2) - Math.min(num1,num2) ;
        }
        if(add.isChecked()){
            correctAns = Math.max(num1,num2) + Math.min(num1,num2);
        }
    }

    public boolean judge(){
        int answer0 = 0;
        answer0 = Integer.valueOf(answer.getText().toString());
        if(answer0==correctAns){
            return true;
        } else {
            return false;
        }
    }

    public void restart(){
        count = 0;
        score = 0;
    }
}
